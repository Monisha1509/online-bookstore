const mongoose = require("mongoose");

mongoose.connect(
  "mongodb+srv://monishabalsum_db_user:OrodRvhRwEegV84p@cluster0.wuyvil7.mongodb.net/bookstore"
);

const BookSchema = new mongoose.Schema({
  title: String,
  description: String,
  price: Number,
  image: String,
  isSold: { type: Boolean, default: false }
});

const Book = mongoose.model("Book", BookSchema);

const books = [
  {
    title: "Rich Dad Poor Dad",
    description: "Personal finance classic.",
    price: 299,
    image: "https://covers.openlibrary.org/b/id/8225261-L.jpg"
  },
  {
    title: "Think and Grow Rich",
    description: "Success mindset and wealth.",
    price: 349,
    image: "https://covers.openlibrary.org/b/id/7267286-L.jpg"
  },
  {
    title: "Atomic Habits",
    description: "Build good habits, break bad ones.",
    price: 399,
    image: "https://covers.openlibrary.org/b/id/9251992-L.jpg"
  },
  {
    title: "The Psychology of Money",
    description: "Timeless lessons on money.",
    price: 450,
    image: "https://covers.openlibrary.org/b/id/10594763-L.jpg"
  },
  {
    title: "Ikigai",
    description: "Japanese secret to long life.",
    price: 299,
    image: "https://covers.openlibrary.org/b/id/9331736-L.jpg"
  },
  {
    title: "Deep Work",
    description: "Focus in a distracted world.",
    price: 420,
    image: "https://covers.openlibrary.org/b/id/8231994-L.jpg"
  },
  {
    title: "The Alchemist",
    description: "Follow your dreams.",
    price: 280,
    image: "https://covers.openlibrary.org/b/id/8128691-L.jpg"
  },
  {
    title: "Start With Why",
    description: "Leadership inspiration.",
    price: 360,
    image: "https://covers.openlibrary.org/b/id/8155436-L.jpg"
  },
  {
    title: "Zero to One",
    description: "Startup thinking.",
    price: 390,
    image: "https://covers.openlibrary.org/b/id/8235116-L.jpg"
  },
  {
    title: "Mindset",
    description: "The power of growth mindset.",
    price: 310,
    image: "https://covers.openlibrary.org/b/id/8226091-L.jpg"
  }
];

async function seed() {
  await Book.deleteMany();
  await Book.insertMany(books);
  console.log("✅ 10 Books inserted successfully");
  mongoose.disconnect();
}

seed();
