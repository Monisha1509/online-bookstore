const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },

  description: {
    type: String,
    required: true
  },

  price: {
    type: Number,
    required: true
  },

  image: {
    type: String,
    required: true
  },

  // ✅ IMPORTANT: used to hide purchased books
  isSold: {
    type: Boolean,
    default: false
  }
});

module.exports = mongoose.model("Book", bookSchema);
