const express = require("express");
const Book = require("../models/Book");
const router = express.Router();

// Get unsold books
router.get("/", async (req, res) => {
  const books = await Book.find({ isSold: false });
  res.json(books);
});

// Get book by ID
router.get("/:id", async (req, res) => {
  const book = await Book.findById(req.params.id);
  res.json(book);
});

module.exports = router;
