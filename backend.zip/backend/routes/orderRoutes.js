const express = require("express");
const router = express.Router();
const Order = require("../models/Order");
const Book = require("../models/Book");

router.post("/", async (req, res) => {
  try {
    const { customer, items, totalAmount } = req.body;

    // 1️⃣ Save order
    const order = new Order({
      customer,
      items,
      totalAmount
    });

    await order.save();

    // 2️⃣ Mark each purchased book as SOLD
    for (let item of items) {
      await Book.findByIdAndUpdate(item.bookId, {
        isSold: true
      });
    }

    res.status(201).json({
      message: "Order placed successfully",
      order
    });

  } catch (error) {
    res.status(500).json({
      message: "Failed to place order"
    });
  }
});

module.exports = router;
